# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contenttypes', '0001_initial'),
        ('notifications', '0003_auto_20141029_1143'),
    ]

    operations = [
        migrations.CreateModel(
            name='Watched',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('object_id', models.PositiveIntegerField()),
                ('created_date', models.DateTimeField(verbose_name='created date', auto_now_add=True)),
                ('content_type', models.ForeignKey(to='contenttypes.ContentType')),
                ('user', models.ForeignKey(related_name='watched', verbose_name='user', to=settings.AUTH_USER_MODEL)),
                ('project', models.ForeignKey(to='projects.Project', verbose_name='project', related_name='watched')),

            ],
            options={
                'verbose_name': 'Watched',
                'verbose_name_plural': 'Watched',
            },
            bases=(models.Model,),
        ),
        migrations.AlterUniqueTogether(
            name='watched',
            unique_together=set([('content_type', 'object_id', 'user', 'project')]),
        ),
    ]
